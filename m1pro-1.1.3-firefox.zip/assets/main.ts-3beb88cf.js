import{b as t}from"./booter-d661b336.js";t((()=>import("./main-starter-9cfce7d0.js").then((t=>t.default()))));
